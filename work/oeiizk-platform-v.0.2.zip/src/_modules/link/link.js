'use strict';

// Constructor
var Link = function() {
  this.name = 'Link';
  console.log('%s module', this.name);
};

module.exports = Link;
